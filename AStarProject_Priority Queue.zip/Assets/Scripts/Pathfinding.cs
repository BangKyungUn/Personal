﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Diagnostics;

public class Pathfinding : MonoBehaviour {

	public Transform seeker, target;
	Grid grid;
    public bool isList;
	void Start () 
	{
		grid = GetComponent<Grid> ();	
	}

	void Update()
	{
        if(Input.GetMouseButton(0))
        {
            FindPath(seeker.position, target.position);
        }
    }

	void FindPath(Vector3 startPos, Vector3 targetPos)
	{
        Stopwatch sw = new Stopwatch();
        sw.Start();

		Node startNode = grid.NodeFromWorldPosition(startPos);
		Node targetNode = grid.NodeFromWorldPosition(targetPos);

        if (isList)
        {
            List<Node> openSet = new List<Node>();
            HashSet<Node> closedSet = new HashSet<Node>();
            openSet.Add(startNode);
            startNode.gCost = 0;
            startNode.hCost = GetDistance(startNode, targetNode);

            while (openSet.Count > 0)
            {

                // OpenSet에서 가장 낮은 fCost를 가지는 노드를 가져온다. 
                // 만일 fCost가 동일할 경우 gCost가 적은 쪽을 택함. 
                Node currentNode = openSet[0];
                for (int i = 1; i < openSet.Count; i++)
                {
                    if (openSet[i].fCost < currentNode.fCost)
                    {
                        currentNode = openSet[i];
                    }
                    else if (openSet[i].fCost == currentNode.fCost)
                    {
                        if (openSet[i].gCost < currentNode.gCost)
                        {
                            currentNode = openSet[i];
                        }
                    }
                }

                // 만일 현재 노드가 최종 노드면 탐색을 종료한다.
                if (currentNode == targetNode)
                {
                    RetracePath(startNode, targetNode);
                    sw.Stop();
                    UnityEngine.Debug.Log("Search Complete :" + sw.ElapsedMilliseconds + "ms");
                    return;
                }

                // 해당 노드를 OpenSet에서 빼내고 ClosedSet에 추가한다.
                openSet.Remove(currentNode);
                closedSet.Add(currentNode);

                // 해당 노드에 인접한 이웃 노드를 구한다.  
                List<Node> neighbors = grid.GetNeighbours(currentNode);
                foreach (Node n in neighbors)
                {
                    // 이웃 노드가 ClosedSet에 있거나 걸어다니지 못하는 곳이면 제외한다.
                    if (closedSet.Contains(n) || !n.walkable)
                        continue;

                    // 이웃 노드의 fCost를 모두 계산한다.
                    int gCost = GetDistance(n, currentNode);
                    int hCost = GetDistance(n, targetNode);
                    int fCost = gCost + hCost;

                    // 이웃 노드가 OpenSet에 있는지 검사한다.  
                    if (openSet.Contains(n))
                    {
                        // 있으면 fCost를 비교하고 신규 노드의 fCost 값이 더 적으면 값을 재조정. ( gCost와 부모 변경 )
                        // 이 때도 fCost가 같은 경우 gCost가 적은 쪽을 택함.
                        if (fCost < n.fCost || (fCost == n.gCost && hCost < n.gCost))
                        {
                            n.gCost = gCost;
                            n.parent = currentNode;
                        }
                    }
                    else
                    {
                        // 없으면 gCost와 hCost를 할당하고 CurrentNode를 부모 노드로 등록한 후 OpenSet에 추가한다.
                        n.gCost = gCost;
                        n.hCost = hCost;
                        n.parent = currentNode;
                        openSet.Add(n);
                    }
                }
            }
        }
        else
        {
            PriorityQueue<Node> openSet = new PriorityQueue<Node>();
            HashSet<Node> closedSet = new HashSet<Node>();
            openSet.Enqueue(startNode);
            startNode.gCost = 0;
            startNode.hCost = GetDistance(startNode, targetNode);

            while (openSet.Count() > 0)
            {

                // OpenSet에서 가장 낮은 fCost를 가지는 노드를 가져온다. 
                // 만일 fCost가 동일할 경우 gCost가 적은 쪽을 택함. 
                Node currentNode = openSet.Dequeue();

                // 만일 현재 노드가 최종 노드면 탐색을 종료한다.
                if (currentNode == targetNode)
                {
                    RetracePath(startNode, targetNode);

                    sw.Stop();
                    UnityEngine.Debug.Log("Search Complete :" + sw.ElapsedMilliseconds + "ms");
                    return;
                }

                // 해당 노드를 OpenSet에서 빼내고 ClosedSet에 추가한다.
                closedSet.Add(currentNode);

                // 해당 노드에 인접한 이웃 노드를 구한다.  
                List<Node> neighbors = grid.GetNeighbours(currentNode);
                foreach (Node n in neighbors)
                {
                    // 이웃 노드가 ClosedSet에 있거나 걸어다니지 못하는 곳이면 제외한다.
                    if (closedSet.Contains(n) || !n.walkable)
                        continue;

                    // 이웃 노드의 fCost를 모두 계산한다.
                    int gCost = GetDistance(n, currentNode);
                    int hCost = GetDistance(n, targetNode);
                    int fCost = gCost + hCost;

                    // 이웃 노드가 OpenSet에 있는지 검사한다.  
                    if (openSet.Contains(n))
                    {
                        // 있으면 fCost를 비교하고 신규 노드의 fCost 값이 더 적으면 값을 재조정. ( gCost와 부모 변경 )
                        // 이 때도 fCost가 같은 경우 gCost가 적은 쪽을 택함.
                        if (fCost < n.fCost || (fCost == n.gCost && hCost < n.gCost))
                        {
                            n.gCost = gCost;
                            n.parent = currentNode;
                            openSet.Rearrange();
                        }
                    }
                    else
                    {
                        // 없으면 gCost와 hCost를 할당하고 CurrentNode를 부모 노드로 등록한 후 OpenSet에 추가한다.
                        n.gCost = gCost;
                        n.hCost = hCost;
                        n.parent = currentNode;
                        openSet.Enqueue(n);
                    }
                }
            }
        }
    }

	void RetracePath(Node startNode, Node endNode)
	{
		List<Node> path = new List<Node> ();
		Node currentNode = endNode;

		while (currentNode != startNode) {
			path.Add (currentNode);
			currentNode = currentNode.parent;
		}

		path.Reverse ();
		grid.path = path;
	}

	int GetDistance(Node nodeA, Node nodeB)
	{
		int dstX = Mathf.Abs(nodeA.gridX - nodeB.gridX);
		int dstY = Mathf.Abs(nodeA.gridY - nodeB.gridY);

		if(dstX > dstY)
		{
			return 14*dstY + 10*(dstX - dstY);
		}

		return 14*dstX + 10*(dstY - dstX);
	}
}
