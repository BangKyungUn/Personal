﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


public class Node : IComparable<Node> {

	public bool walkable;
	public Vector3 worldPosition;
	public int gridX;
	public int gridY;

	public int gCost;
	public int hCost;
	public Node parent;

	public Node(bool _walkable, Vector3 _worldPos, int _gridX, int _gridY)
	{
		this.walkable = _walkable;
		this.worldPosition = _worldPos;
		gridX = _gridX;
		gridY = _gridY;
	}

	public int fCost
	{
		get
		{
			return gCost + hCost;
		}
	}

    public int CompareTo(Node other)
    {
        //if(this.fCost != other.fCost) return Math.Min(this.fCost, other.fCost);
        //else if(this.fCost == other.fCost)
        //{
        //    int minGCost = Math.Min(this.gCost, other.gCost);
        //    if (minGCost == this.gCost) return this.fCost;
        //    else if (minGCost == other.gCost) return other.fCost;
        //}

        if (this.fCost != other.fCost)
        {
            if (this.fCost < other.fCost) return -1;
            else if (this.fCost > other.fCost) return 1;
        }
        else if (this.fCost == other.fCost)
        {
            if (this.gCost < other.gCost) return -1;
            else if (this.gCost > other.gCost) return 1;
        }
        return 0;
    }
}
