﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Employee : IComparable<Employee>
{
	public string lastName;
	public double priority; // Smaller values are higher priority

	public Employee(string lastName, double priority)
	{
		this.lastName = lastName;
		this.priority = priority;
	}

	public override string ToString()
	{
		return "(" + lastName + ", " + priority.ToString("F1") + ")";
	}

	public int CompareTo(Employee other)
	{
		if (this.priority  < other.priority) return -1;
		else if (this.priority  > other.priority) return 1;
		else return 0;
	}
}

public class PriorityQueue<T> where T : IComparable<T>
{
	private List <T> data;

	public PriorityQueue()
	{
		this.data = new List <T>();
	}

    public bool Contains(T item)
    {
        return data.Contains(item);
    }

    public void Rearrange()
    {
        for (int i = (Count() / 2) - 1; i >= 0; i--)
        {
            heapify(i);
        }
    }

	public void Enqueue(T item)
	{
		data.Add(item);
		int ci = data.Count - 1;
		while (ci  > 0)
		{
			int pi = (ci - 1) / 2;
            if (data[ci].CompareTo(data[pi]) >= 0)
            { 
                break;
            }
			T tmp = data[ci]; data[ci] = data[pi]; data[pi] = tmp;
			ci = pi;
		}
	}

	public T Dequeue()
	{
		// Assumes pq isn't empty
		int li = data.Count - 1;
		T frontItem = data[0];
		data[0] = data[li];
		data.RemoveAt(li);

		--li;
		int pi = 0;
		while (true)
		{
			int ci = pi * 2 + 1;
			if (ci  > li) break;
			int rc = ci + 1;
			if (rc  <= li && data[rc].CompareTo(data[ci])  < 0)
				ci = rc;
			if (data[pi].CompareTo(data[ci])  <= 0) break;
			T tmp = data[pi]; data[pi] = data[ci]; data[ci] = tmp;
			pi = ci;
		}
		return frontItem;
	}

	public int Count()
	{
		return data.Count;
	}

	public T Peek()
	{
		T frontItem = data[0];
		return frontItem;
	}

	public override string ToString()
	{
		string s = "";
		for (int i = 0; i  < data.Count; ++i)
			s += data[i].ToString() + " ";
		s += "count = " + data.Count;
		return s;
	}

	public bool IsConsistent()
	{
		if (data.Count == 0) return true;
		int li = data.Count - 1; // last index
		for (int pi = 0; pi  < data.Count; ++pi) // each parent index
		{
			int lci = 2 * pi + 1; // left child index
			int rci = 2 * pi + 2; // right child index
			if (lci  <= li && data[pi].CompareTo(data[lci])  > 0) return false;
			if (rci  <= li && data[pi].CompareTo(data[rci])  > 0) return false;
		}
		return true; // Passed all checks
	}

    public void heapify(int i)
    {
        int min = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;


        if (i < Count() && data[left].CompareTo(data[min]) < 0) min = left;

        if (right < Count() && data[right].CompareTo(data[min]) < 0) min = right;

        if (min != i)
        {
            T tmp = data[i];
            data[i] = data[min];
            data[min] = data[i];

            min = i;
            heapify(min);
        }
    }
}

public class PriorityQueueTest : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
	//	Debug.Log("Begin Priority Queue demo");
	//	Debug.Log("Creating priority queue of Employee items");
		PriorityQueue <Employee > pq = new PriorityQueue <Employee >();

		// Demo code here 
		Employee e1 = new Employee("Aiden", 1.0);
		Employee e2 = new Employee("Baker", 2.0);

	//	Debug.Log("Adding " + e1.ToString() + " to priority queue");
		pq.Enqueue(e1);
	//	Debug.Log("Adding " + e2.ToString() + " to priority queue");
		pq.Enqueue(e2);

		if (pq.Count () > 0) {
			Employee e = pq.Peek ();
	//		Debug.Log("The front employee is " + e.ToString ());
		}


		TestPriorityQueue (10000);
	//	Debug.Log("End Priority Queue demo");
	}

	void TestPriorityQueue(int numOperations)
	{
		System.Random rand = new System.Random(0);
		PriorityQueue <Employee > pq = 
			new PriorityQueue <Employee >();
		for (int op = 0; op  < numOperations; ++op)
		{
			int opType = rand.Next(0, 2);

			if (opType == 0) // enqueue
			{
				string lastName = op + "man";
				double priority = 
					(100.0 - 1.0) * rand.NextDouble() + 1.0;
				pq.Enqueue(new Employee(lastName, priority));
				if (pq.IsConsistent() == false)
				{
			//		Debug.Log("Test fails after enqueue operation # " + op);
				}
			}
			else // Dequeue
			{
				if (pq.Count()  > 0)
				{
					Employee e = pq.Dequeue();
					if (pq.IsConsistent() == false)
					{
				//		Debug.Log("Test fails after dequeue operation # " + op);
					}
				}
			}
		} // for
	//	Debug.Log("\nAll tests passed");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
